#include <stdio.h>
#include <modbus.h>
#include <unistd.h>
#include <string.h>
#include <pthread.h>
#include <errno.h>
#include <fcntl.h>
#include <syslog.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <errno.h>

modbus_t *ctx;
key_t key;
int shmid;
char *shmaddr;
pthread_mutex_t mutex; // 定义互斥锁

int shm()
{
    key = ftok("/home/hq/modbus_project.c", 1);
    shmid = shmget(key, 128, IPC_CREAT | IPC_EXCL | 0666);
    if (shmid <= 0)
    {
        // 如果是已存在的错误不能让程序退出
        if (errno == EEXIST) // 如果已存在则直接打开共享内存
            shmid = shmget(key, 128, 0666);
        else // 其他错误则让程序退出
        {
            perror("shmget err");
            return -1;
        }
    }
    printf("shmid: %d\n", shmid);
    shmaddr = (char *)shmat(shmid, NULL, 0);
    if (shmaddr == (char *)-1)
    {
        perror("shmat err");
        return -1;
    }
    return 0;
}

void *read_data()
{
    uint16_t data[4] = {0};
    while (1)
    {
        pthread_mutex_lock(&mutex);
        modbus_read_registers(ctx, 0, 4, data);// 加锁：访问共享内存前获取锁
        for (int i = 0; i < 4; i++)
        {
            shmaddr[i] = data[i];//shmaddr[0-3]存储光线、加速度x、加速度y、加速度z
        }
        printf("光线:%d 加速度x:%d 加速度y:%d 加速度z:%d\n",
               data[0], data[1], data[2], data[3]);
        // 解锁：完成操作后释放锁
        pthread_mutex_unlock(&mutex);
        sleep(1);
    }
}

void *write_data()
{
    int num, stat;
    while (1)
    {
        // 加锁：读取共享内存中的控制参数
        pthread_mutex_lock(&mutex);
        num = shmaddr[4];
        stat = shmaddr[5];
        modbus_write_bit(ctx, num, stat);
        // 解锁：完成读取后释放锁
        pthread_mutex_unlock(&mutex);

        usleep(100000); // 短暂延迟，避免频繁占用CPU
    }
}

int main(int argc, char const *argv[])
{
    // 初始化互斥锁
    if (pthread_mutex_init(&mutex, NULL) != 0)
    {
        perror("mutex init failed");
        return -1;
    }

    if (shm() != 0)
    {
        return -1;
    }

    pthread_t tid1, tid2;
    ctx = modbus_new_tcp("172.20.10.12", 502); // 创建Modbus TCP实例
    modbus_set_slave(ctx, 1);

    if (modbus_connect(ctx))
    {
        perror("connect err");
        return -1;
    }

    pthread_create(&tid1, NULL, read_data, NULL);
    pthread_create(&tid2, NULL, write_data, NULL);

    pthread_join(tid1, NULL);
    pthread_join(tid2, NULL);

    // 销毁互斥锁
    pthread_mutex_destroy(&mutex);

    modbus_close(ctx);
    modbus_free(ctx);
    return 0;
}
