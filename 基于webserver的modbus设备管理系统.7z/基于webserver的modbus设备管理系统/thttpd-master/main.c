#include"thttpd.h"
#include <sys/types.h>
#include <sys/wait.h>
#include <modbus.h>

modbus_t *ctx;
key_t key;
int shmid;
int shm()//创建共享内存
{
	key=ftok("/home/hq/modbus_project.c",1);
    shmid=shmget(key, 128, IPC_CREAT | IPC_EXCL | 0666);
    if (shmid <= 0)
    {
        
        // 如果是已存在的错误不能让程序退出
        if (errno == EEXIST) // 如果已存在则直接打开共享内存
            shmid = shmget(key, 128, 0666);
        else // 其他错误则让程序退出
        {
            perror("shmget err");
            return -1;
        }
    }
    printf("shmid1: %d\n", shmid);
    shmaddr=(char*)shmat(shmid,NULL,0);
    if(shmaddr==(char*)-1)
    {
        perror("shmat err");
        return -1;
    }
}

static void* msg_request(void *arg)
{
	//这里客户端描述符通过参数传进来了
	int sock=(int)arg;

	// 一般情况下，线程终止后，其终止状态一直保留到其它线程调用pthread_join获取它的状态为止。
	//但是线程也可以被置为detach状态，这样的线程一旦终止就立刻回收它占用的所有资源，而不保留终止状态。
	pthread_detach(pthread_self());	

	//handler_msg作为所有的请求处理入口
	return (void*)handler_msg(sock);
}

int main(int argc,char* argv[])
{
	shm();
	for(int i=0;i<4;i++)
	{
		printf("shmaddr[%d]: %d\n", i, shmaddr[i]);//测试modbus项目中的数据是否实现互通
	}
	//如果不传递端口，那么使用默认端口80
	int port = 80;

	if(argc > 1)
	{
		port = atoi(argv[1]);
	}

	//初始化服务器
	int lis_sock=init_server(port);

	while(1)
	{
		
		struct sockaddr_in peer;
		socklen_t len=sizeof(peer);
		
		int sock=accept(lis_sock,(struct sockaddr*)&peer,&len);
		
		if(sock<0)
		{
			perror("accept failed");
			continue;
		}
		
		//每次接收一个链接后，会自动创建一个线程，这实际上就是线程服务器模型的应用
		pthread_t tid;
		if(pthread_create(&tid,NULL,msg_request,(void*)sock)>0)
		{
			perror("pthread_create failed");
			close(sock);
		}
	}
	return 0;
}
